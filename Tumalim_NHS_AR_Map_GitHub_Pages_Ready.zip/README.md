# Tumalim National High School — Project QR-MAP

Mobile-friendly AR safety and evacuation map for Tumalim NHS.

## Files

- `index.html` — main mobile web application
- `manifest.webmanifest` — installable web-app metadata
- `sw.js` — service worker for repeat/offline app-shell loading
- `.nojekyll` — prevents unnecessary Jekyll processing
- `.github/workflows/pages.yml` — automatic GitHub Pages deployment

## GitHub Pages setup

1. Create a GitHub repository, for example:
   `tumalim-nhs-ar-map`
2. Upload **all files and folders** from this package.
3. Commit to the `main` branch.
4. Open **Settings → Pages**.
5. Under **Build and deployment → Source**, choose **GitHub Actions**.
6. Wait for the Actions workflow to finish.
7. GitHub will show the live website address under **Settings → Pages**.

A project site normally uses:
`https://YOUR-GITHUB-USERNAME.github.io/tumalim-nhs-ar-map/`

GitHub Pages provides HTTPS, which is important because the camera-based AR feature requires a secure context.

## QR code

After the site is live, create the final QR code using the exact live URL shown by GitHub Pages. Do not use the temporary Google Drive folder URL if the goal is to open the AR Map directly.

## Important safety note

This digital map is an orientation and preparedness tool. It must not replace the school's approved evacuation plan, emergency signage, drills, official announcements, or instructions from teachers and the DRRM team.
